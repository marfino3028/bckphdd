A Pen created at CodePen.io. You can find this one at http://codepen.io/lukepeters/pen/bfFur.

 Using CSS for responsive table layouts instead of floats. Responsive (everything goes down to one row each), too.