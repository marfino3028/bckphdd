-= Membuat Header, Footer dan Nomor Halaman pada PDF =-

Dibuat oleh	: Achmad Solichin
Situs 		: http://achmatim.net
Tanggal 	: 30 April 2012

Contoh Program ini mendemonstrasikan bagaimana membuah header, footer dan nomor halaman pada dokumen PDF dengan PHP dan library FPDF. Tutorial lengkap dapat dilihat di http://achmatim.net/2012/04/30/membuat-header-footer-dan-nomor-halaman-pada-pdf-dengan-php-fpdf/

Dapatkan tutorial komputer lainnya dengan mengunjungi situs http://achmatim.net

Maju terus ilmu pengetahuan Indonesia!
