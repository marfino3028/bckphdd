<?php

if(isset($_GET['Area_chart'])){
	
	if($_GET['Area_chart'] == 1)	{
		echo json_encode(array( array('y' => 2011, 'a' => 45, 'b' => 32), 
		   					array('y' => 2012, 'a' => 65, 'b' => 58), 
		   					array('y' => 2013, 'a' => 75, 'b' => 1), 
		   					array('y' => 2014, 'a' => 82, 'b' => 38), 
		   					array('y' => 2015, 'a' => 67, 'b' => 42) ));			
	}
	if($_GET['Area_chart'] == 2) {
		echo	json_encode(array( array('y' => 2011, 'a' => 45, 'b' => 32), 
		   					array('y' => 2012, 'a' => 82, 'b' => 38), 
		   					array('y' => 2013, 'a' => 75, 'b' => 1), 
		   					array('y' => 2014, 'a' => 39, 'b' => 12), 		   					
		   					array('y' => 2015, 'a' => 65, 'b' => 58), 
		   					array('y' => 2016, 'a' => 67, 'b' => 42) ));
	}
}

?>