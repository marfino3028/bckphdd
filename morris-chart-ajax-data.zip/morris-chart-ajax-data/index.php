<!DOCTYPE html>
<html lang="en"><head>
<title> Morris.js Dynamic Data Example PHP Mysql - Kvcodes </title> 

<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no">
<meta name="theme-color" content="#343D46">  
<meta name="msapplication-navbutton-color" content="#343D46"> 
<meta name="apple-mobile-web-app-status-bar-style" content="#343D46">
<!--- SEO Things Added by Varadha -->
<meta content='True' name='HandheldFriendly'/>
<meta content='global' name='distribution'/>
<meta content='all' name='audience'/>
<meta content='general' name='rating'/>
<meta content='all' name='robots'/>
<meta content='en-us' name='language'/>
<meta content='USA' name='country'/>
<meta content='320' name='MobileOptimized'/>
<meta content='Varadharaj V' name='author'/>
<meta content='IE=edge,chrome=1' http-equiv='X-UA-Compatible'/>
<meta content='width=device-width, initial-scale=1' name='viewport'/>
<meta content='Copyright (c) 2013 - <?php echo date("Y");?>' Kvcodes' name='dcterms.dateCopyrighted'/>
<meta content='text/html; charset=UTF-8' http-equiv='Content-Type'/>
<link href='http://feeds.feedburner.com/KvCodes' rel='alternate' title='Kvcodes - A Place for Web Tutorials' type='application/rss+xml'/>
<link href='https://plus.google.com/+VaradharajVel' rel='author'/>
<link href='http://www.kvcodes.com' rel='shortlink'/>
<link href='https://plus.google.com/+VaradharajVel' rel='publisher'/>
<link href='https://plus.google.com/u/0/b/103705444781603570835/+Kvcodes' rel='publisher'/>
<meta name="keywords" content="demo codes, kvcodes demo, demoing articles, articles demo, Kvcodes Projects Demo"/>
<link rel="canonical" href="http://demo.kvcodes.com/" />
<link rel="publisher" href="https://plus.google.com/+Kvcodes/posts"/>
<meta property="og:locale" content="en_US" />
<meta property="og:type" content="article" />
<meta property="og:title" content="Simple Popup Div Using jQuery " />
<meta property="og:description" content="A Simple Popup can help you to show a simple popup on any device. Without using Extra jQuery plugin and other stuffs. Its very simple to go." />
<meta property="og:url" content="http://www.kvcodes.com/2016/11/simple-popup-div-using-jquery/" />
<meta property="og:site_name" content="Kvcodes" />
<meta property="article:publisher" content="https://www.facebook.com/kvcodes?ref=hl" />
<meta property="article:author" content="https://www.facebook.com/kvvaradha" />
<meta property="article:tag" content="Kvcodes Demo" />
<meta property="article:tag" content="PRojects" />
<meta property="article:tag" content="Demo" />
<meta property="article:tag" content="WordPress" />
<meta property="article:section" content="HTML" />
<meta property="article:published_time" content="2014-02-11T17:21:45+00:00" />
<meta property="article:modified_time" content="2016-10-20T11:09:52+00:00" />
<meta property="og:updated_time" content="2016-10-20T11:09:52+00:00" />
<meta property="og:image:width" content="1135" />
<meta property="og:image:height" content="754" />
<style> 
/* Reset */

	html, body, div, span, applet, object, iframe, h1, h2, h3, h4, h5, h6, p, blockquote, pre, a, abbr, acronym, address, big, cite, code, del, dfn, em, img, ins, kbd, q, s, samp, small, strike, strong, sub, sup, tt, var, b, u, i, center, dl, dt, dd, ol, ul, li, fieldset, form, label, legend, table, caption, tbody, tfoot, thead, tr, th, td, article, aside, canvas, details, embed, figure, figcaption, footer, header, hgroup, menu, nav, output, ruby, section, summary, time, mark, audio, video {
		margin: 0;
		padding: 0;
		border: 0;
		font-size: 100%;
		font: inherit;
		font-family: 'PT Sans';
		vertical-align: baseline;
	}

	article, aside, details, figcaption, figure, footer, header, hgroup, menu, nav, section {
		display: block;
	}

	body {
		line-height: 1;
	}

	ol, ul {
		list-style: none;
	}

	blockquote, q {
		quotes: none;
	}

	blockquote:before, blockquote:after, q:before, q:after {
		content: '';
		content: none;
	}
   h3 {
      color: #fff;
      font-size: 20px;
   }
	table {
		border-collapse: collapse;
		border-spacing: 0;
	}

	body {
		-webkit-text-size-adjust: none;
		background: #203748;
	}

	html, body, #header, #main {
		height:100%;
	}
	* { 
		margin: 0;
		padding: 0;
	}
	a {
		text-decoration: none;
	}
	#footer a { 
	color: #03A9F4;
}
#footer a:hover { 
	color: #39d084;
}
#wrap {
  min-height: 100%;
}

#main {
  overflow: auto;
  padding-bottom: 60px; /* must be same height as the footer */
}

#footer {
  position: relative;
  margin-top: -60px; /* negative value of footer height */
  height: 180px;
  clear: both;
  color:  #fff;
}

#header {
	background: #39d084;
    height: 30px;
    color: #fff;
    padding:1%;
}
#header a {
	color:#fff;
}
#header .logo {
	width: 100%;
	text-align: center;
	float: left;
}
#header .logo a {
	font-size:24px;
}
#header ul {
	list-style: none;
	float:right;
}
#header ul li {
	float:left;
	margin: 0 8px;
}
.header-wrap{
	margin: 0 auto;
    width: 800px;
}
a{
	cursor: pointer;
}
.content {
	padding: 8px;
	line-height: 25px;
	font-size: 16px;
	margin: 0 auto;
    width: 800px;
}

#footer {
	height:20px;
	padding: 20px;
	background: #355267;
}

h1 { 
	font-size: 20px;
	font-weight: 600;
	text-align: center;
    margin-top: 2%;
	color: #16b4fb;
}
p {
    color: #d4d3d3;
}

li {
    padding-bottom: 8px;
}
#subscriber_form{ display:none; }
#subscriber_form {
	margin: 0;
    width: 100%;
    z-index: 2;
    height: 100%;
    max-height: 1080px;
    position: fixed;
    background: rgba(70, 71, 72, 0.69);
}
#sub_div_form { 
	width: 240px;  
	height: 210px;
    margin: 0 auto;
    background: white;
    margin-top: 15%;
    padding: 45px;
    border: 1px solid #9E9E9E;
    border-radius: .25em .25em .4em .4em;
    text-align: center;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
}
#sub_div_form span {
	position: relative;
    float: right;
    font-weight: 700;
    margin-top: -40px;
    height: 15px;
    font-size: 18px;
    width: 15px;
    line-height: 15px;
    margin-right: -40px;
    border: 2px solid;
    border-radius: 90px;
    padding: 7px;
}

span#kv_form_close:hover {
    color: #e0190b;
}

@media screen and (max-width: 440px) {
	#sub_div_form { 
		width: 290px; 
		padding: 35px;
	}
}
</style>

<script src="http://www.kvcodes.com/theme/js/jquery.min.js" > </script> 
<script> 
$(document).ready(function(){
	
	$('#subscriber_form').delay(1000).fadeIn('slow'); 
 
	$("#subscriber_form").on('click', function(e){
		 if (e.target !== this)
			return;
		else{
			$(this).hide();
		}
	});

	$("#show_popup").on("click", function() {
		$("#subscriber_form").show();
	});
	$("#kv_form_close").on('click', function(e){		
		$('#subscriber_form').fadeOut('slow');
	});
});
</script> 
<script async src="http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script>
  (adsbygoogle = window.adsbygoogle || []).push({
    google_ad_client: "ca-pub-9927149984527168",
    enable_page_level_ads: true
  });
</script>
</head> 
<body> 

<div id="wrap">			
			<div id="header"><!-- Header -->
                <div class="header-wrap"> 
                <div class="logo">
					 <a href="http://www.kvcodes.com/2017/07/morris-js-dynamic-data-example-php-mysql"> <img src="http://www.kvcodes.com/theme/images/kv_logo.png" alt="Home" style="    height: 50px; margin-top: -10px; vertical-align: middle;"> - Demo</a>
          		</div>
				 <!-- Nav -->
							<nav id="main-menu" class="main_nav" ></nav>	
								
				</div>

				</div> 
<div id="main" class="content"  > <h1>Morris.js Dynamic Data Example PHP Mysql </h1><br />
<div class="top_adspace_content">

			<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
			<!-- leaderboard -->
			<ins class="adsbygoogle"
				 style="display:inline-block;width:728px;height:90px"
				 data-ad-client="ca-pub-9927149984527168"
				 data-ad-slot="7855465734"></ins>
			<script>
			(adsbygoogle = window.adsbygoogle || []).push({});
			</script>
			
		</div>


<div style="padding: 5% 0; text-align:center; "> 

	<div class="row">  <div class="col-md-12">  <div class="col-md-6">  </div> <div class="col-md-6" > <select id="SalesPeriods" class="form-control"> <option value="1">One</option><option value="2">Two</option></select></div> </div></div><div id="Area_chart" style="height: 250px;"></div>
</div>
<div class="top_adspace_content">

			<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
			<!-- leaderboard -->
			<ins class="adsbygoogle"
				 style="display:inline-block;width:728px;height:90px"
				 data-ad-client="ca-pub-9927149984527168"
				 data-ad-slot="7855465734"></ins>
			<script>
			(adsbygoogle = window.adsbygoogle || []).push({});
			</script>
			
		</div>
</div></div><!-- Footer -->
				<div id="footer">			
					 
					<!-- Copyright -->
						<div class="copyright">
							<div class="container">
								<ul class="menu">
									<li style="float:left;"> Copyrights &copy; Kvcodes.com  <?php echo date('Y'); ?> All rights reserved</li>
									<li style="float:right;">Design and Development: <a href="http://www.kvcodes.com">Kvcodes</a></li>
								</ul>
							</div>
						</div>

				</div>            
 <script src="http://code.jquery.com/jquery-1.10.2.min.js"></script>
<!-- Morris -->  
<link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">
<!--<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>-->
<script src="http://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
<script src="http://cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>
<script type="text/javascript">

  $(function() {
   //  ##########################
    var Area_chart = Morris.Area({
      element: 'Area_chart',  
      behaveLikeLine: true,
      parseTime : false, 
      data: [ ],
      xkey: 'y',
      ykeys: ['a', 'b'],
      labels: ['Sales', 'Cost'],
      pointFillColors: ['#707f9b'],
      pointStrokeColors: ['#ffaaab'],
      lineColors: ['#f26c4f', '#00a651', '#00bff3'],
      redraw: true      
    });

    $("#SalesPeriods").on("change", function(){
     var selectedID = $(this).val(); 
     $.ajax({
            type: "POST",
            url: "ajax.php?Area_chart="+selectedID,
            data: 0,
            dataType: 'json',
            success: function(data){
              console.log(data);
              Area_chart.setData(data);
               /* setCookie('numbers',data,3);
                $('.flash').show();
                $('.flash').html("Template Updated")*/
            }
          });
  });
  });
   $(document).ready(function(e){
      $("#SalesPeriods").trigger("change");
  });
</script>

</body>
</html> 


