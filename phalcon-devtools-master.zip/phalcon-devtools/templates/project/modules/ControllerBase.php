<?php
declare(strict_types=1);

namespace @@namespace@@\Modules\Frontend\Controllers;

use Phalcon\Mvc\Controller;

class ControllerBase extends Controller
{

}
