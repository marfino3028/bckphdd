<?php

require '../app/bootstrap_web.php';
