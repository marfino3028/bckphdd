Vökuró is an open source project and a volunteer effort.

*We only accept bug reports, new feature requests and pull requests in GitHub*.

Vökuró does not have human resources fully dedicated to the maintenance of this software.
If you want something to be improved or you want a new feature please submit a Pull Request.

Thanks! <br />
Phalcon Team
