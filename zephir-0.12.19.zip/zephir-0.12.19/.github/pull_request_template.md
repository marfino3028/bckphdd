Hello!

* Type: bug fix | new feature | code quality | documentation
* Link to issue:

In raising this pull request, I confirm the following:

- [ ] I have checked that another pull request for this purpose does not exist
- [ ] I wrote some tests for this PR
- [ ] I updated the CHANGELOG

Small description of change:

Thanks
