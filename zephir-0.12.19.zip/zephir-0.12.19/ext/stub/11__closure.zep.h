
extern zend_class_entry *stub_11__closure_ce;

ZEPHIR_INIT_CLASS(stub_11__closure);

PHP_METHOD(stub_11__closure, __invoke);

ZEPHIR_INIT_FUNCS(stub_11__closure_method_entry) {
	PHP_ME(stub_11__closure, __invoke, NULL, ZEND_ACC_PUBLIC|ZEND_ACC_FINAL)
	PHP_FE_END
};
