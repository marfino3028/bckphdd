
extern zend_class_entry *stub_12__closure_ce;

ZEPHIR_INIT_CLASS(stub_12__closure);

PHP_METHOD(stub_12__closure, __invoke);

ZEPHIR_INIT_FUNCS(stub_12__closure_method_entry) {
	PHP_ME(stub_12__closure, __invoke, NULL, ZEND_ACC_PUBLIC|ZEND_ACC_FINAL)
	PHP_FE_END
};
