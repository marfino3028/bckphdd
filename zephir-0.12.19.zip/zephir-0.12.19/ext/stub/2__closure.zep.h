
extern zend_class_entry *stub_2__closure_ce;

ZEPHIR_INIT_CLASS(stub_2__closure);

PHP_METHOD(stub_2__closure, __invoke);

ZEPHIR_INIT_FUNCS(stub_2__closure_method_entry) {
	PHP_ME(stub_2__closure, __invoke, NULL, ZEND_ACC_PUBLIC|ZEND_ACC_FINAL)
	PHP_FE_END
};
